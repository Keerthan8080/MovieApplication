//
//  ViewController.swift
//  MovieShow
//
//  Created by Edwin Varghese on 26/12/23.
//

import UIKit
import CoreData
import StoreKit



class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    var listItemArray = [ListItem]()
    //var filteredData = [ListItem]()
    
    
var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var mySearchText: UISearchBar!
   @IBOutlet weak var collectionView: UICollectionView!
    
   // @IBOutlet weak var bookButton: UIBarButtonItem!
    //@IBOutlet weak var nameLabel: UITextField!
    //@IBOutlet weak var dateLabel: UIDatePicker!
    //@IBOutlet weak var bookButton: UIButton!
    
    @IBOutlet weak var nameTextField: UITextField!
       @IBOutlet weak var dateTextField: UITextField!
    
    let images = ["one", "two", "three", "four", "five"]
        let titles = ["Devara", "Avengers", "Salaar", "TIGER 3", "Loki"]
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return images.count
        }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "postCell", for: indexPath) as! PostCell
            cell.image.image = UIImage(named: images[indexPath.row])
            cell.pTitle.text = titles[indexPath.row]
            cell.pAuthor.text = "AVAILABLE NOW"
            return cell
        }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        loadData()
   
        
    
    }
    
    
   /*func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText != ""
        {
            listItemArray =   ListItem.Filter{
                (ListItem: String) in return ListItem.contains(searchText)
            }
        }
        else
        {
            print("kindly Enter search Text First")
            filteredData = listItemArray
            tableView.reloadData()
            
        }
    }*/
    /*@IBAction func bookNow(_ sender: Any) {
        if let bookButton = sender as? UIButton {
            bookButton.isEnabled = false
            bookButton.setTitle("Booking...", for: .disabled)
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0){
                print("Booking Successful!")
                bookButton.isEnabled = true
                bookButton.setTitle("Book Now", for: .normal)
            }
        }
    }*/
    @IBAction func rating(_ sender: Any) {
        SKStoreReviewController.requestReview()
    }
    
    @IBAction func rate(_ sender: Any) {
        SKStoreReviewController.requestReview()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listItemArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ItemCell", for: indexPath)
        let item = listItemArray[indexPath.row]
        cell.textLabel?.text = item.name
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var textField = UITextField()
        let alert = UIAlertController(title: "Change Movie Name", message: "", preferredStyle: .alert)
        let action = UIAlertAction(title: "Update Movie", style: .default) { (action) in
            self.listItemArray[indexPath.row].setValue(textField.text, forKey: "name")
            self.saveData()
        }
        
        
        alert.addAction(action)
        alert.addTextField { (alertTextField) in
            alertTextField.placeholder = "New Item Here"
            textField = alertTextField
        }
        present(alert, animated: true, completion: nil)
        
    }
  
    // to delete the data swipe towards left
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath){
        if editingStyle == .delete{
            tableView.beginUpdates()
            listItemArray.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            tableView.endUpdates()
        }
    }
       /* context.delete(listItemArray[indexPath.row])
        listItemArray.remove(at: indexPath.row)
        saveData()
    }*/
   /* @IBAction  func bookButtonTapped(_ sender: UIButton){
         guard let name = nameLabel.text
         else
         {
             return
         }
         let selectedDate = dateLabel.date
         print("Booking for \(name) on \(selectedDate) is processed!")
     }
             
     }*/
    @IBAction func addButtonPressed(_ sender: Any) {
        var textField = UITextField()
        let alert = UIAlertController(title: "Create New Movie", message: "", preferredStyle: .alert)
        let action = UIAlertAction(title: "Add Movie", style: .default) { (action) in
            let newItem = ListItem(context: self.context)
            newItem.name = textField.text
            self.listItemArray.append(newItem)
            self.saveData()
        }
        alert.addAction(action)
        alert.addTextField { (alertTextField) in
            alertTextField.placeholder = "New Item Here"
            textField = alertTextField
        }
    
  present(alert, animated: true, completion: nil)
}
    func saveData() {
        do {
            try  context.save()
        } catch {
            print("Error saving context\(error)")
        }
        tableView.reloadData()
        
    }
    func loadData() {
        let request : NSFetchRequest<ListItem> = ListItem.fetchRequest()
        do {
            //listItemArray = try context.fetch(request)
            if let fetchedData = try (context.fetch(request) as? [ListItem]) {
                listItemArray = fetchedData
            }
            else {
                print(" fetcehedData is not of type [ListItem")
            }
        } catch {
            print("Error loading date \(error)")
        }
        if listItemArray == nil {
            listItemArray = []
            // }
            
            tableView.reloadData()
        }
    }
    
    
    @IBAction func bookButtonTapped(_ sender: UIButton) {
    
    
   // @IBAction func bookButtonTapped(_ sender: UIButton) {
        guard let name = nameTextField.text, !name.isEmpty,
              let date = dateTextField.text, !date.isEmpty else {
            // Show alert for incomplete fields
            return
        }
        // Perform booking logic here
        let confirmationMessage = "Booking confirmed for \(name) on \(date)"
        showAlert(message: confirmationMessage)
    }

    func showAlert(message: String) {
        let alertController = UIAlertController(title: "Booking", message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
        
    }
}

//Scroll up to see more images
class PostCell: UICollectionViewCell{
    @IBOutlet weak var background: UIView!
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var pTitle: UILabel!
    //@IBOutlet weak var pSubTitle: UILabel!
    @IBOutlet weak var pAuthor: UILabel!
    
    override func awakeFromNib() {
        background.layer.cornerRadius = 10
        image.layer.cornerRadius = 10
    }
}
